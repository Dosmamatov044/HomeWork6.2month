package com.company;

public interface Husband <T extends Number> {
T getId();
int getSum();



}

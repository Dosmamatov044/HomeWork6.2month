package com.company;

public class Main {

    public static void main(String[] args) {


    Wife wife=new Wife(2,3.3);
        System.out.println(wife.getChildren()+" "+ wife.getGrandfather());
    Wife wife1=new Wife(3);
        System.out.println(wife1.getChildren());




    wife.getId();       //это 2 просто так
    wife.getSum();
    }
}
